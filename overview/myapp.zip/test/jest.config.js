module.exports = {
  globalSetup: './mongo/setup.js',
  globalTeardown: './mongo/teardown.js',
  testEnvironment: './mongo/mongo-environment.js'
};